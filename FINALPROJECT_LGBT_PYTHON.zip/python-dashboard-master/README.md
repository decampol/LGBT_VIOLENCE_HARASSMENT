Dashboard Python - De Campos Lisa ; Luximon Davina

Afin de pouvoir éxecuter le fichier, il est nécéssaire d'avoir dans le répertoire courant les 
deux fichiers .csv. La map est optionelle car elle est automatiquement recréée lors de l'exécution.
Aucun autre problème ne devrait se présenter lors de l'exécution du Dash.